<?php
if (!defined('ABSPATH')) { exit; }

final class MLV2_Admin_Ajustes {

    public static function render(): void {
        if (!current_user_can('manage_options')) { wp_die('No autorizado'); }

        $msg = '';
        $err = '';

        if (!empty($_POST['mlv2_ajuste_submit'])) {
            check_admin_referer('mlv2_ajustes_contables');

            $modo = sanitize_text_field(wp_unslash($_POST['modo_ajuste'] ?? 'cliente'));
            $rut = sanitize_text_field(wp_unslash($_POST['cliente_rut'] ?? ''));
            $cliente_id = (int)($_POST['cliente_id'] ?? 0);
            $locales_sel = isset($_POST['locales_seleccion']) && is_array($_POST['locales_seleccion']) ? array_map('sanitize_text_field', wp_unslash($_POST['locales_seleccion'])) : [];
            $tipo = sanitize_text_field(wp_unslash($_POST['tipo_ajuste'] ?? ''));
            $monto = (int)($_POST['monto'] ?? 0);
            $origen_saldo = sanitize_text_field(wp_unslash($_POST['origen_saldo'] ?? 'ajuste'));
            $clasificacion = sanitize_text_field(wp_unslash($_POST['clasificacion'] ?? 'correccion'));
            $motivo = sanitize_text_field(wp_unslash($_POST['motivo'] ?? ''));
            $observacion = sanitize_text_field(wp_unslash($_POST['observacion'] ?? ''));

            if ($monto <= 0 || $motivo === '') {
                $err = 'Monto y motivo son obligatorios.';
            } else {
                if ($modo === 'cliente') {
                    if ($cliente_id <= 0 && $rut !== '' && class_exists('MLV2_Ledger')) {
                        $cliente_id = (int) MLV2_Ledger::find_cliente_by_rut($rut);
                    }
                    if ($cliente_id <= 0) {
                        $err = 'Cliente no encontrado. Usa RUT o selector.';
                    }
                } else {
                    $locales_sel = array_values(array_filter(array_map('trim', (array)$locales_sel)));
                    if (empty($locales_sel)) {
                        $err = 'Debes seleccionar al menos un local.';
                    }
                }
            }

            if ($err === '') {
                if (!in_array($tipo, ['abonar','descontar'], true)) {
                    $err = 'Tipo de ajuste inválido.';
                }
                if (!in_array($origen_saldo, ['reciclaje','incentivo','ajuste'], true)) {
                    $origen_saldo = 'ajuste';
                }
                if (!in_array($clasificacion, ['correccion','regularizacion_historica'], true)) {
                    $clasificacion = 'correccion';
                }
            }

            if ($err === '') {
                $signo = ($tipo === 'descontar') ? -1 : 1;
                $monto_calc = $signo * $monto;

                global $wpdb;
                $table = MLV2_DB::table_movimientos();

                $detalle = [
                    'tipo' => 'ajuste',
                    'origen' => $origen_saldo,
                    'clasificacion' => $clasificacion,
                    'ajuste' => [
                        'tipo' => 'manual',
                        'motivo' => $motivo,
                        'signo' => ($signo > 0 ? '+' : '-'),
                        'observacion' => $observacion,
                        'creado_por' => (int)get_current_user_id(),
                    ],
                    'hist' => [
                        [
                            'ts' => current_time('mysql'),
                            'actor_user_id' => (int)get_current_user_id(),
                            'actor_role' => 'administrator',
                            'accion' => 'ajuste_manual_admin',
                            'estado' => 'retirado',
                            'payload' => [
                                'monto' => $monto,
                                'tipo' => $tipo,
                            ],
                        ],
                    ],
                ];

                $now = current_time('mysql');
                $total_movs = 0;
                $targets = [];
                if ($modo === 'cliente') {
                    $targets[] = [
                        'local' => self::get_primary_local_for_cliente($cliente_id),
                        'clientes' => [$cliente_id],
                    ];
                } else {
                    foreach ($locales_sel as $lc) {
                        $clientes_ids = self::get_clientes_ids_by_local($lc);
                        if (empty($clientes_ids)) {
                            $err = 'El local ' . esc_html($lc) . ' no tiene clientes asociados.';
                            break;
                        }
                        $targets[] = ['local' => $lc, 'clientes' => $clientes_ids];
                    }
                }

                if ($err === '') {
                    foreach ($targets as $t) {
                        $lc = (string)($t['local'] ?? '');
                        $clientes_ids = (array)($t['clientes'] ?? []);
                        $count = count($clientes_ids);
                        if ($count <= 0) { continue; }

                        $base = intdiv(abs($monto_calc), $count);
                        $rest = abs($monto_calc) - ($base * $count);

                        foreach ($clientes_ids as $idx => $cid) {
                            $monto_cli = $base + ($idx < $rest ? 1 : 0);
                            if ($monto_cli <= 0) continue;
                            $monto_cli = $signo * $monto_cli;

                            $detalle['ajuste']['modo'] = $modo;
                            $detalle['ajuste']['local'] = $lc;

                            $insert = [
                                'tipo' => ($monto_cli >= 0 ? 'ingreso' : 'gasto'),
                                'cliente_user_id' => $cid,
                                'cliente_rut' => (string) get_user_meta($cid, 'mlv_rut', true),
                                'cliente_telefono' => (string) get_user_meta($cid, 'mlv_telefono', true),
                                'local_codigo' => $lc,
                                'cantidad_latas' => 0,
                                'valor_por_lata' => 0,
                                'monto_calculado' => $monto_cli,
                                'origen_saldo' => $origen_saldo,
                                'mov_ref_id' => null,
                                'is_system_adjustment' => 1,
                                'clasificacion_mov' => $clasificacion,
                                'estado' => 'retirado',
                                'detalle' => wp_json_encode($detalle, JSON_UNESCAPED_UNICODE),
                                'created_by_user_id' => (int)get_current_user_id(),
                                'validated_by_user_id' => null,
                                'created_at' => $now,
                                'updated_at' => $now,
                            ];

                            $ok = $wpdb->insert($table, $insert);
                            if ($ok) {
                                $total_movs++;
                                if (class_exists('MLV2_Ledger') && method_exists('MLV2_Ledger','recalc_saldo_cliente')) {
                                    MLV2_Ledger::recalc_saldo_cliente($cid);
                                }
                            }
                        }
                    }
                }

                if ($err === '' && $total_movs <= 0) {
                    $err = 'No se pudo guardar el ajuste.';
                }

                if ($err === '') {
                    if (class_exists('MLV2_Audit')) {
                        MLV2_Audit::add('movimiento_manual_adjustment_create', 'movimiento', 0, null, [
                            'modo' => $modo,
                            'monto' => $monto_calc,
                            'origen_saldo' => $origen_saldo,
                            'clasificacion' => $clasificacion,
                            'locales' => $locales_sel,
                            'movimientos' => $total_movs,
                        ]);
                    }
                    $msg = 'Ajuste contable registrado correctamente.';
                }
            }
        }

        $clientes = class_exists('MLV2_Admin_Query') ? MLV2_Admin_Query::get_clientes_dropdown() : [];

        echo '<div class="wrap">';
        echo '<h1>Ajustes contables</h1>';
        echo '<p class="description">Permite corregir saldos con abonos o descuentos. Puedes aplicarlo a un cliente o repartirlo entre clientes de uno o varios locales.</p>';
        if ($msg) { echo '<div class="notice notice-success"><p>' . esc_html($msg) . '</p></div>'; }
        if ($err) { echo '<div class="notice notice-error"><p>' . esc_html($err) . '</p></div>'; }

        echo '<form method="post">';
        wp_nonce_field('mlv2_ajustes_contables');

        echo '<table class="form-table" role="presentation">';
        echo '<tr><th scope="row">Modo</th>';
        echo '<td><label><input type="radio" name="modo_ajuste" value="cliente" checked> Cliente</label> &nbsp; '
           . '<label><input type="radio" name="modo_ajuste" value="local"> Repartir por local(es)</label></td></tr>';
        echo '<tr><th scope="row"><label for="cliente_rut">Cliente por RUT</label></th>';
        echo '<td><input type="text" id="cliente_rut" name="cliente_rut" class="regular-text" placeholder="12.345.678-9"></td></tr>';

        echo '<tr><th scope="row"><label for="cliente_id">O seleccionar cliente</label></th>';
        echo '<td><select id="cliente_id" name="cliente_id" class="regular-text">';
        echo '<option value="0">— Seleccionar —</option>';
        foreach ($clientes as $c) {
            echo '<option value="' . esc_attr((string)$c['id']) . '">' . esc_html($c['label']) . '</option>';
        }
        echo '</select></td></tr>';

        $locales = class_exists('MLV2_Admin_Query') ? MLV2_Admin_Query::get_locales_disponibles() : [];
        $locales_labels = class_exists('MLV2_Admin_Query') ? MLV2_Admin_Query::get_locales_labels($locales) : [];
        echo '<tr id="mlv2-aj-row-locales"><th scope="row"><label for="locales_seleccion">Locales (reparto)</label></th>';
        echo '<td><select id="locales_seleccion" name="locales_seleccion[]" class="regular-text" multiple size="6">';
        foreach ($locales as $lc) {
            $lbl = $locales_labels[$lc] ?? $lc;
            $count = self::count_clientes_by_local($lc);
            $label = $lbl . ' (' . $count . ' clientes)';
            echo '<option value="' . esc_attr($lc) . '">' . esc_html($label) . '</option>';
        }
        echo '</select><p class="description">Selecciona uno o más locales para repartir el ajuste entre sus clientes.</p></td></tr>';

        echo '<tr><th scope="row"><label for="tipo_ajuste">Tipo</label></th>';
        echo '<td><select id="tipo_ajuste" name="tipo_ajuste" class="regular-text">';
        echo '<option value="abonar">Abonar saldo</option>';
        echo '<option value="descontar">Descontar saldo</option>';
        echo '</select></td></tr>';

        echo '<tr><th scope="row"><label for="monto">Monto</label></th>';
        echo '<td><input type="number" id="monto" name="monto" min="1" step="1" class="regular-text" required></td></tr>';

        echo '<tr><th scope="row"><label for="origen_saldo">Origen del saldo</label></th>';
        echo '<td><select id="origen_saldo" name="origen_saldo" class="regular-text">';
        echo '<option value="reciclaje">Reciclaje</option>';
        echo '<option value="incentivo">Incentivo</option>';
        echo '<option value="ajuste" selected>Ajuste</option>';
        echo '</select></td></tr>';

        echo '<tr><th scope="row"><label for="clasificacion">Clasificación</label></th>';
        echo '<td><select id="clasificacion" name="clasificacion" class="regular-text">';
        echo '<option value="correccion">Corrección</option>';
        echo '<option value="regularizacion_historica">Regularización histórica</option>';
        echo '</select></td></tr>';

        echo '<tr><th scope="row"><label for="motivo">Motivo</label></th>';
        echo '<td><input type="text" id="motivo" name="motivo" class="regular-text" required></td></tr>';

        echo '<tr><th scope="row"><label for="observacion">Observación</label></th>';
        echo '<td><input type="text" id="observacion" name="observacion" class="regular-text"></td></tr>';

        echo '</table>';

        submit_button('Registrar ajuste', 'primary', 'mlv2_ajuste_submit');
        echo '</form>';
        $js = <<<'JS'
(function(){
    function qs(id){ return document.getElementById(id); }
    function setVisible(el, show){ if(!el) return; el.style.display = show ? "table-row" : "none"; }
    function sync(){
        var modo = document.querySelector("input[name='modo_ajuste']:checked");
        var isLocal = modo && modo.value === "local";
        setVisible(qs("mlv2-aj-row-locales"), isLocal);
        setVisible(qs("cliente_rut") ? qs("cliente_rut").closest("tr") : null, !isLocal);
        setVisible(qs("cliente_id") ? qs("cliente_id").closest("tr") : null, !isLocal);
    }
    document.querySelectorAll("input[name='modo_ajuste']").forEach(function(r){ r.addEventListener("change", sync); });
    sync();
})();
JS;
        echo '<script>' . $js . '</script>';
        echo '</div>';
    }

    private static function get_clientes_ids_by_local(string $local_codigo): array {
        $local_codigo = trim($local_codigo);
        if ($local_codigo === '') return [];

        $ids = [];
        if (class_exists('MLV2_DB')) {
            global $wpdb;
            $table = MLV2_DB::table_clientes_almacenes();
            $ids = $wpdb->get_col($wpdb->prepare(
                "SELECT DISTINCT cliente_user_id FROM {$table} WHERE local_codigo=%s",
                $local_codigo
            ));
        }

        $q = new WP_User_Query([
            'role' => 'um_cliente',
            'fields' => 'ID',
            'number' => 5000,
            'meta_query' => [
                [
                    'key' => 'mlv_local_codigo',
                    'value' => $local_codigo,
                    'compare' => '=',
                ],
            ],
        ]);
        $legacy = $q->get_results();
        $merged = array_merge((array)$ids, (array)$legacy);
        $merged = array_values(array_unique(array_map('intval', $merged)));

        return $merged;
    }

    private static function count_clientes_by_local(string $local_codigo): int {
        $ids = self::get_clientes_ids_by_local($local_codigo);
        return count($ids);
    }

    private static function get_primary_local_for_cliente(int $cliente_id): string {
        $cliente_id = (int)$cliente_id;
        if ($cliente_id <= 0) return '';

        $locales = class_exists('MLV2_Admin_Query') ? MLV2_Admin_Query::get_locales_for_user($cliente_id) : [];
        if (!empty($locales)) {
            $locales = array_values(array_filter(array_map('trim', (array)$locales)));
            if (!empty($locales)) return (string)$locales[0];
        }
        $legacy = trim((string) get_user_meta($cliente_id, 'mlv_local_codigo', true));
        return $legacy;
    }
}
